package com.test.mytest;

/**
 * Created by Alexander_Petrovskiy on 5/26/2016.
 */
public enum NewEnum {
        One,
        Two,
        Three
}
