package com.test.mytest;

import com.epam.jdi.uitests.core.interfaces.base.IElement;
import com.epam.jdi.uitests.core.interfaces.common.*;
import com.epam.jdi.uitests.core.interfaces.complex.IMenu;
import com.epam.jdi.uitests.web.selenium.elements.base.Element;
import com.epam.jdi.uitests.web.selenium.elements.common.*;
import com.epam.jdi.uitests.web.selenium.elements.complex.Menu;
import com.sun.javafx.iio.common.ImageLoaderImpl;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Alexander_Petrovskiy on 5/26/2016.
 */
public class Analyzer {

    static WebDriver webDriver;

    public static boolean isNullOrEmpty(String s) {
        return s == null || s.length() == 0;
    }

    boolean testAsButton(WebElement element, String xPath) {
        IButton probableButton;
        try {
            System.out.println("test as a button");
            // probableButton = new Button(By.xpath(xPath));
            probableButton = new Button();
            System.out.println(null == probableButton);
            probableButton.getClass().getAnnotations()
        }
        catch (Exception e) {
            System.out.println(e.getStackTrace().toString());
            return false;
        }
        if (isNullOrEmpty(probableButton.getText()))
            return false;
        if (isNullOrEmpty(probableButton.getName()))
            return false;
        if (!probableButton.isDisplayed())
            return false;
        try {
            probableButton.click();
            webDriver.navigate().back();
            return true;
        }
        catch (Exception e) {
            return false;
        }
    }

    boolean testAsLink(WebElement element, String xPath) {
        try {
            ILink probableLink = new Link(By.xpath(xPath));
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }

        return true;
    }

    boolean testAsText(WebElement element, String xPath) {
        try {
            IText probablyText = new Text(By.xpath(xPath));
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
        return true;
    }

    boolean testAsLabel(WebElement element, String xPath) {
        try {
            ILabel probableLabel = new Label(By.xpath(xPath));
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
        return true;
    }

    boolean testAsCheckBox(WebElement element, String xPath) {
        try {
            ICheckBox probableCheckBox = new CheckBox(By.xpath(xPath));
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
        return true;
    }

    boolean testAsTextArea(WebElement element, String xPath) {
        try {
            ITextArea probableTextArea = new TextArea(By.xpath(xPath));
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
        return true;
    }

    boolean testAsTextField(WebElement element, String xPath) {
        try {
            ITextField probableTextField = new TextField(By.xpath(xPath));
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
        return true;
    }

    boolean testAsMenu(WebElement element, String xPath) {
        try {
            List<IMenu<NewEnum>> probableMenu = new ArrayList<>();
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
        return true;
    }



    public java.lang.Class GetElementType(String urlPath, String xPath) {
        System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver.exe");
        webDriver = new ChromeDriver();
        webDriver.get(urlPath);
        WebElement element = webDriver.findElement(By.xpath(xPath));
        System.out.println(element.getAttribute("id"));
        System.out.println(element.getAttribute("name"));
        System.out.println(element.getAttribute("class"));
        System.out.println(element.toString());

        // System.out.println(element.getText());
        // System.out.println(element.toString());

        if (testAsButton(element, xPath))
            return IButton.class;
        if (testAsLink(element, xPath))
            return ILink.class;
        if (testAsText(element, xPath))
            return IText.class;
        if (testAsLabel(element, xPath))
            return ILabel.class;
        if (testAsCheckBox(element, xPath))
            return ICheckBox.class;
        if (testAsTextArea(element, xPath))
            return ITextArea.class;
        if (testAsTextField(element, xPath))
            return ITextField.class;
        // if (testAsMenu(element, xPath))
        //     return IMenu.class;
        return IElement.class;
    }
}
