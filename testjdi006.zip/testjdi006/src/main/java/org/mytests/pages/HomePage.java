package org.mytests.pages;

import com.epam.jdi.uitests.web.selenium.elements.composite.WebPage;

/**
 * Created by Roman_Iovlev on 10/22/2015.
 */
public class HomePage extends WebPage {

}
